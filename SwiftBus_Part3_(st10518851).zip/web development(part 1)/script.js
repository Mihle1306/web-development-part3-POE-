/* SwiftBus Part 3 JavaScript enhancements */
document.addEventListener("DOMContentLoaded", () => {
  // Add a visible current-page state to navigation.
  const currentPage = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".main-nav a").forEach(link => {
    if (link.getAttribute("href") === currentPage) {
      link.setAttribute("aria-current", "page");
    }
  });

  // Filter the route table dynamically.
  const search = document.getElementById("routeSearch");
  if (search) {
    const rows = [...document.querySelectorAll(".routes-section tbody tr")];
    const feedback = document.getElementById("searchFeedback");
    search.addEventListener("input", () => {
      const query = search.value.trim().toLowerCase();
      let visible = 0;
      rows.forEach(row => {
        const match = row.textContent.toLowerCase().includes(query);
        row.hidden = !match;
        if (match) visible++;
      });
      feedback.textContent = visible ? `${visible} route${visible === 1 ? "" : "s"} found.` : "No routes match your search.";
    });
  }

  // Common client-side validation and email preparation.
  function attachEmailForm(formId, feedbackId, subjectPrefix, enquiryMode = false) {
    const form = document.getElementById(formId);
    if (!form) return;
    const feedback = document.getElementById(feedbackId);
    form.addEventListener("submit", event => {
      event.preventDefault();
      const name = form.querySelector('[name="fullname"], [name="name"]');
      const email = form.querySelector('[name="email"]');
      const phone = form.querySelector('[name="phone"]');
      const message = form.querySelector('[name="message"]');
      const type = form.querySelector('[name="enquiry"], [name="type"]');
      if (name && name.value.trim().length < 2) {
        feedback.textContent = "Please enter your full name (at least 2 characters).";
        name.focus(); return;
      }
      if (!email || !email.checkValidity()) {
        feedback.textContent = "Please enter a valid email address.";
        if (email) email.focus(); return;
      }
      if (phone && phone.value.trim() && !/^[0-9+() -]{7,20}$/.test(phone.value.trim())) {
        feedback.textContent = "Please enter a valid phone number.";
        phone.focus(); return;
      }
      if (!type || !type.value) {
        feedback.textContent = "Please select a message or enquiry type.";
        if (type) type.focus(); return;
      }
      if (!message || message.value.trim().length < 10) {
        feedback.textContent = "Please enter a message of at least 10 characters.";
        if (message) message.focus(); return;
      }
      const subject = `${subjectPrefix}: ${type.value}`;
      const body = [
        `Name: ${name.value.trim()}`,
        `Email: ${email.value.trim()}`,
        `Phone: ${phone ? phone.value.trim() : "Not provided"}`,
        `Type: ${type.value}`,
        "",
        "Message:",
        message.value.trim()
      ].join("\n");
      feedback.textContent = "Your details are valid. Your email application will open so you can review and send the message.";
      // Replace this address with the organisation's intended recipient if needed.
      window.location.href = `mailto:ST10518851@rcconnect.edu.za?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
    form.addEventListener("reset", () => { if (feedback) feedback.textContent = ""; });
  }
  attachEmailForm("enquiryForm", "enquiryFeedback", "SwiftBus Enquiry", true);
  attachEmailForm("contactForm", "contactFeedback", "SwiftBus Contact Message");

  // Smooth reveal for cards as they enter the page.
  const cards = document.querySelectorAll(".service-card, .contact-card, .location-card");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.12 });
    cards.forEach(card => { card.classList.add("reveal"); observer.observe(card); });
  }
});
