# SwiftBus Website — Part 3 (WEDE5020)

## Project overview
SwiftBus is a student website project presenting bus travel services and route information in South Africa. It is built with HTML, CSS and vanilla JavaScript.

## Pages
- `index.html` — home page
- `about.html` — about SwiftBus
- `services.html` — route and service information, including route search
- `enquiry.html` — customer enquiry form
- `contact.html` — contact information and general message form
- `style.css` — responsive styles and interaction states
- `script.js` — client-side form validation, route filtering, navigation state and card reveal effects
- `robots.txt` and `sitemap.xml` — search crawler guidance and site map

## Part 3 functionality
- Added page-specific descriptions, keywords, author and robots metadata, plus Open Graph title/description metadata.
- Added route search that filters the route table as the user types.
- Added JavaScript client-side checks for names, email addresses, phone number format, selected form type and message length.
- Added contact form fields for basic contact details, message type and a full message.
- Validated forms prepare an email using a `mailto:` link so the visitor can review and send it in their own email application.
- Added active navigation state, accessible live feedback, focus styles, reduced-motion support and subtle card reveal transitions.
- Added lazy loading to images and retained the responsive CSS layout.

## Form submission note
This is a static front-end website. The forms do not send data to a server or database. After validation, the browser opens the visitor's configured email application with a prepared message addressed to `ST10518851@rcconnect.edu.za`. Replace this recipient with the correct organisation email if required. For true AJAX submission, spam protection and reliable server-side delivery, connect a form backend or server endpoint before deployment.

## Changelog
### Part 3 — 21 October 2026
- Added JavaScript file `script.js` and linked it to all five HTML pages.
- Added page-specific SEO descriptions and metadata, including Open Graph metadata.
- Added dynamic route-table filtering on the Services page with an accessible result message.
- Added JavaScript validation and clear feedback to the Enquiry form.
- Added a separate General Contact Message form with message-type selection and email preparation.
- Added active-page navigation indication, card reveal transitions, visible keyboard focus and reduced-motion support.
- Added lazy loading to images to reduce initial loading work.
- Added `robots.txt` and `sitemap.xml` for crawler guidance and site discovery.
- Reviewed existing page navigation and preserved the SwiftBus website structure and image assets.

## References
- Google Search Central (n.d.) *SEO Starter Guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 21 October 2026).
- MDN Web Docs (n.d.) *Client-side form validation*. Available at: https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation (Accessed: 21 October 2026).
- MDN Web Docs (n.d.) *Intersection Observer API*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API (Accessed: 21 October 2026).
- GitHub Docs (n.d.) *GitHub Pages*. Available at: https://docs.github.com/en/pages (Accessed: 21 October 2026).

## Deployment checklist
1. Commit and push all updated files to the GitHub repository.
2. In the repository, open **Settings → Pages**.
3. Under build and deployment, choose **Deploy from a branch**, select the branch containing the website (usually `main`) and the root folder, then save.
4. Wait for GitHub Pages to publish the site and test all pages and forms on desktop and mobile.
5. Submit the repository URL and the published website URL in the LMS.

## Suggested Git commit messages
1. `Add page-specific SEO metadata`
2. `Add JavaScript route search and filtering`
3. `Validate enquiry form and prepare email`
4. `Add general contact form and validation`
5. `Improve responsive accessibility and animations`
6. `Add robots sitemap and Part 3 changelog`

### Part 3 visible design refresh
The Part 3 update also includes a visible design refresh in `style.css`: a blue/teal gradient header, sticky dark navigation with a gold active/hover state, more prominent hero sections, rounded image treatments, elevated cards, updated buttons, clearer form fields and responsive mobile adjustments. Refresh the browser after replacing the files to see these changes.
